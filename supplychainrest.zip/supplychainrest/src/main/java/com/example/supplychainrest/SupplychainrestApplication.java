package com.example.supplychainrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupplychainrestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupplychainrestApplication.class, args);
	}

}
