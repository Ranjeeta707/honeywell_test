package com.example.supplychainrest.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
public class SupplyRest {


    @GetMapping("/getLogBook")

    public String GetLogBook()
    {
        return "Welcome to SupplyChain application logbook";
    }
}
